plugins { id("com.android.application"); id("org.jetbrains.kotlin.android"); id("org.jetbrains.kotlin.plugin.compose") }
android { namespace="com.example.amarhisab"; compileSdk=36
 defaultConfig { applicationId="com.example.amarhisab"; minSdk=24; targetSdk=36; versionCode=2; versionName="2.0" }
 buildFeatures { compose=true }
}
dependencies { val bom=platform("androidx.compose:compose-bom:2025.08.00"); implementation(bom); implementation("androidx.activity:activity-compose:1.10.1"); implementation("androidx.compose.ui:ui"); implementation("androidx.compose.ui:ui-tooling-preview"); implementation("androidx.compose.material3:material3"); implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.9.2"); implementation("androidx.datastore:datastore-preferences:1.1.7"); debugImplementation("androidx.compose.ui:ui-tooling") }
