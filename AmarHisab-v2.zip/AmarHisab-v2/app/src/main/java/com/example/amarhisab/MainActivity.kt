package com.example.amarhisab

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

private val Context.store by preferencesDataStore("amar_hisab")
data class Tx(val id:Long,val amount:Double,val type:String,val category:String,val note:String,val date:String)
class VM(private val c:Context):ViewModel(){
 var list by mutableStateOf(listOf<Tx>()); private set
 private val k=stringPreferencesKey("tx"); private val scope=kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO)
 init{load()}
 private fun load(){scope.launch{val a=JSONArray(c.store.data.first()[k]? :"[]");val r=mutableListOf<Tx>();for(i in 0 until a.length()){val o=a.getJSONObject(i);r+=Tx(o.getLong("id"),o.getDouble("amount"),o.getString("type"),o.optString("category"),o.optString("note"),o.getString("date"))};list=r.sortedByDescending{it.id}}}
 fun save(t:Tx){list=(list.filterNot{it.id==t.id}+t).sortedByDescending{it.id};persist()}
 fun del(id:Long){list=list.filterNot{it.id==id};persist()}
 private fun persist(){scope.launch{val a=JSONArray();list.forEach{t->a.put(JSONObject().apply{put("id",t.id);put("amount",t.amount);put("type",t.type);put("category",t.category);put("note",t.note);put("date",t.date)})};c.store.edit{it[k]=a.toString()}}}
}
@Composable fun App(vm:VM=viewModel(factory=androidx.lifecycle.viewmodel.initializer.viewModelFactory{initializer{VM(androidx.compose.ui.platform.LocalContext.current)}})){
 var add by remember{mutableStateOf<String?>(null)};var edit by remember{mutableStateOf<Tx?>(null)}
 val income=vm.list.filter{it.type=="জমা"}.sumOf{it.amount};val out=vm.list.filter{it.type=="খরচ"}.sumOf{it.amount}
 MaterialTheme{Scaffold(topBar={CenterAlignedTopAppBar(title={Text("Amar Hisab",fontWeight=FontWeight.Bold)})}){p->Column(Modifier.padding(p).padding(16.dp)){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){Card(Modifier.weight(1f)){Column(Modifier.padding(14.dp)){Text("মোট জমা");Text("৳ %.2f".format(income),fontWeight=FontWeight.Bold)}};Card(Modifier.weight(1f)){Column(Modifier.padding(14.dp)){Text("মোট খরচ");Text("৳ %.2f".format(out),fontWeight=FontWeight.Bold)}}};Spacer(Modifier.height(8.dp));Card(Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp)){Text("বর্তমান ব্যালেন্স");Text("৳ %.2f".format(income-out),style=MaterialTheme.typography.headlineMedium)}};Spacer(Modifier.height(12.dp));Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Button(Modifier.weight(1f),onClick={add="জমা"}){Text("➕ জমা")};Button(Modifier.weight(1f),onClick={add="খরচ"}){Text("➖ খরচ")}};Spacer(Modifier.height(16.dp));Text("লেনদেন",style=MaterialTheme.typography.titleLarge);LazyColumn{items(vm.list,key={it.id}){t->ListItem(headlineContent={Text("${t.type} • ৳ %.2f".format(t.amount))},supportingContent={Text("${t.category} • ${t.note} • ${t.date}")},trailingContent={Row{TextButton(onClick={edit=t}){Text("Edit")};TextButton(onClick={ {vm.del(t.id)} }){Text("Delete")}}});HorizontalDivider()}}}}}
 add?.let{type->DialogTx(type,null,{add=null}){a,c,n,d->vm.save(Tx(System.currentTimeMillis(),a,type,c,n,d));add=null}}
 edit?.let{old->DialogTx(old.type,old,{edit=null}){a,c,n,d->vm.save(old.copy(amount=a,category=c,note=n,date=d));edit=null}}
}}
@Composable fun DialogTx(type:String,old:Tx?,close:()->Unit,save:(Double,String,String,String)->Unit){var a by remember{mutableStateOf(old?.amount?.toString()? :"")};var cat by remember{mutableStateOf(old?.category? :if(type=="খরচ")"অন্যান্য" else "আয়")};var note by remember{mutableStateOf(old?.note? :"")};var date by remember{mutableStateOf(old?.date? :SimpleDateFormat("dd-MM-yyyy",Locale.getDefault()).format(Date()))};AlertDialog(onDismissRequest=close,title={Text(if(old==null)"$type যোগ করুন" else "$type সম্পাদনা")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){OutlinedTextField(a,{a=it.filter{c->c.isDigit()||c=='.'}},label={Text("টাকার পরিমাণ")});OutlinedTextField(cat,{cat=it},label={Text("ক্যাটাগরি")});OutlinedTextField(note,{note=it},label={Text("বিবরণ")});OutlinedTextField(date,{date=it},label={Text("তারিখ (DD-MM-YYYY)")})}},confirmButton={TextButton(onClick={a.toDoubleOrNull()?.let{save(it,cat,note,date)}}){Text("সংরক্ষণ")}},dismissButton={TextButton(onClick=close){Text("বাতিল")}})}
class MainActivity:ComponentActivity(){override fun onCreate(b:Bundle?){super.onCreate(b);setContent{App()}}}
